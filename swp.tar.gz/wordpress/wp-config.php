<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '123' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '{Py-<t{ .3L~Ld3#z#SxB{/m_{lWe+*}763qd-h{4J;*dB{#2]fcGDe1WtIy|Ch3' );
define( 'SECURE_AUTH_KEY',  'X]Jdp*<e-WA}ovtXQiqJaGo+&H|3`6E~9v*-Hw<C, Mq`F,{ V(q)21U8Pgv6Q+b' );
define( 'LOGGED_IN_KEY',    'nM|#&AdlxIxUxt|GCjr#I+bQxNjR5Jw;=xgH#hG^8Mo7UM/,PR)j>?(uy*D-XC>G' );
define( 'NONCE_KEY',        '{k|,;v]qc@gy}RB#:&mypCuZ2[ovF8<}d2>52?ilbqdyqi]%rJ`vir3^W{78QD#9' );
define( 'AUTH_SALT',        '/`zMdp&t<;!mqI-rm55:H7T=1QL]L+]jp/i|&fz+:x}~#/;M$3I Xegn![$64N$Z' );
define( 'SECURE_AUTH_SALT', 'O67@+72/sTmgHTCh,=0=<_klMahUfVC[%o/5nnjXS<i4>cxt&-YL^{+(Wpe7y]cd' );
define( 'LOGGED_IN_SALT',   '7Cv}6wY@143b%^Kl4I~hRgLnjS,|o~U1b,3-y4)D1m}Lind #{5*HdzQ,Nq1J1>o' );
define( 'NONCE_SALT',       '0k_lY @a|Fb*H[AIf U@~vvN..4w-G-Q.d *w9[brs2/7KL^pXuLfrNnG#wJ,HqB' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
